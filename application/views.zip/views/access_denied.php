<section class="content" ng-app="Common_app" ng-controller="Leave_policyController">
	<div class="container-fluid">
		<!-- <img src="assets/images/access_denied.png" class="img-responcive center-block"> -->
		<center>
			<h1 style="font-size: 200px;">403</h1>

			<h1 style="font-size: 50px;">Forbidden</h1>

			<h1 style="font-size: 25px;">Access to this resource on the server is Denied !</h1>

			<a href="<?php echo base_url().'index'; ?>"><button type="button" class="btn btn-primary"> 	 Home</button></a>
		</center>
	</div>
</section>	
