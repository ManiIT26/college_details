<?php 
class Bio_metricModel Extends CI_Model{

}