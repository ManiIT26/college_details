<?php
class FooterModel Extends CI_Model{


	public function footer(){

		$this->load->view('common/footer');
	}
}


?>